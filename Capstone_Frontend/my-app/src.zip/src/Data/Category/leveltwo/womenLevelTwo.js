export  const womenLevelTwo=[
    {
        "name": "Indian & Fusion Wear",
        "categoryId":"women_indian_and_fusion_wear",
        "parentCategoryId":"women",
        "level":2
    },
    {
        "name": "Western Wear",
        "categoryId":"women_western_wear",
        "parentCategoryId":"women",
        "level":2
    },
    {
        "name": "Footwear",
        "categoryId":"women_footwear",
        "parentCategoryId":"women",
        "level":2
    },
    // {
    //     "name": "Footwear",
    //     "categoryId":"women_footwear",
    //     "parentCategoryId":"women",
    //     "level":2
    // },
    // {
    //     "name": "Footwear",
    //     "categoryId":"women_footwear",
    //     "parentCategoryId":"women",
    //     "level":2
    // }
]