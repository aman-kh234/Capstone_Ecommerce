export  const furnitureLevelTwo=[
    {
        "name": "Bed Linen & Furnishing",
        "categoryId":"furniture_bed",
        "parentCategoryId":"home_furniture",
        "level":2
    },
    {
        "name": "Flooring",
        "categoryId":"flooring",
        "parentCategoryId":"home_furniture",
        "level":2
    },
    {
        "name": "Home Decor",
        "categoryId":"home_decor",
        "parentCategoryId":"home_furniture",
        "level":2
    },
    // {
    //     "name": "Bath",
    //     "categoryId":"bath",
    //     "parentCategoryId":"home_furniture",
    //     "level":2
    // },
    // {
    //     "name": "Lamps & Lights",
    //     "categoryId":"lamps_light",
    //     "parentCategoryId":"home_furniture",
    //     "level":2
    // },
    // {
    //     "name": "Kitchen & Table",
    //     "categoryId":"kitchen_table",
    //     "parentCategoryId":"home_furniture",
    //     "level":2
    // }
]