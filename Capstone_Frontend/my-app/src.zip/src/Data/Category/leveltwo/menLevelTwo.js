export  const menLevelTwo=[
    {
        "name": "Topwear",
        "categoryId":"men_topwear",
        "parentCategoryId":"men",
        "level":2
    },
    {
        "name": "Bottomwear",
        "categoryId":"men_bottomwear",
        "parentCategoryId":"men",
        "level":2
    },
    {
        "name": "Innerwear and Sleepwear",
        "categoryId":"men_innerwear_and_sleepwear",
        "parentCategoryId":"men",
        "level":2
    },
    {
        "name": "Footwear",
        "categoryId":"men_footwear",
        "parentCategoryId":"men",
        "level":2
    },
    // {
    //     "name": "Footwear",
    //     "categoryId":"men_footwear",
    //     "parentCategoryId":"men",
    //     "level":2
    // }
]