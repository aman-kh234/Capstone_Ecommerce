export  const electronicsLevelTwo=[
    {
        "name": "Laptops",
        "categoryId":"laptops",
        "parentCategoryId":"electronics",
        "level":2
    },
    {
        "name": "Tablets",
        "categoryId":"tablets",
        "parentCategoryId":"electronics",
        "level":2
    },
    {
        "name": "Camera",
        "categoryId":"camera",
        "parentCategoryId":"electronics",
        "level":2
    },
    // {
    //     "name": "Bath",
    //     "categoryId":"bath",
    //     "parentCategoryId":"electronics",
    //     "level":2
    // },
    {
        "name": "Speakers",
        "categoryId":"speakers",
        "parentCategoryId":"electronics",
        "level":2
    },
    {
        "name": "Mobiles",
        "categoryId":"mobiles",
        "parentCategoryId":"electronics",
        "level":2
    }
]