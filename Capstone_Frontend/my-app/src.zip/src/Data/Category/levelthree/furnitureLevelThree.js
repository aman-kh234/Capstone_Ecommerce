export  const furnitureLevelThree=[
    {
        "name": "Bedsheets",
        "categoryId":"bedsheets",
        "parentCategoryId":"furniture_bed",
        "parentCategoryName":"Bed Linen & Furnishing",
        "level":3
    },
    {
        "name": "Pillow Covers",
        "categoryId":"pillow_covers",
        "parentCategoryId":"furniture_bed",
        "parentCategoryName":"Bed Linen & Furnishing",
        "level":3
    },
    {
        "name": "Carpets",
        "categoryId":"carpets",
        "parentCategoryId":"flooring",
        "parentCategoryName":"Flooring",
        "level":3
    },
    {
        "name": "Plants",
        "categoryId":"plants",
        "parentCategoryId":"home_decor",
        "parentCategoryName":"Home Decor",
        "level":3
    },
    {
        "name": "Aroma",
        "categoryId":"aroma",
        "parentCategoryId":"home_decor",
        "parentCategoryName":"Home Decor",
        "level":3
    },
   
]