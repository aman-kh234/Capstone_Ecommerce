import React, { useState, useEffect } from "react";
import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import axios from "axios";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  TablePagination, // Import TablePagination component
} from "@mui/material";

// Styling components using MUI
const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: theme.palette.action.hover,
  },
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const statusColors = {
  PENDING: "#FFA500", // Orange
  PLACED: "#00BFFF",  // Deep Sky Blue
  CONFIRMED: "#008000", // Green
  SHIPPED: "#0000FF", // Blue
  DELIVERED: "#32CD32", // Lime Green
  CANCELLED: "#FF6347", // Tomato
};

const statusLabels = {
  PENDING: "Pending",
  PLACED: "Placed",
  CONFIRMED: "Confirmed",
  SHIPPED: "Shipped",
  DELIVERED: "Delivered",
  CANCELLED: "Cancelled",
};

const OrderTable = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState("");
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [page, setPage] = useState(0); // Track the current page
  const [rowsPerPage, setRowsPerPage] = useState(5); // Track rows per page
  const token = localStorage.getItem("sellerToken");

  useEffect(() => {
    // Fetch orders from the backend
    const fetchOrders = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/seller/orders", {
          headers: {
            "Authorization": `Bearer ${token}`,
          },
        });
        setOrders(response.data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching orders", error);
        setLoading(false);
      }
    };
    fetchOrders();
  }, [token]);

  const handleChangeStatus = (orderId, currentStatus) => {
    setSelectedOrderId(orderId);
    setSelectedStatus(currentStatus);
    setOpenDialog(true); // Open the dialog to choose a new status
  };

  const handleUpdateStatus = async () => {
    try {
      // Make a PATCH request to update the status of the order
      const response = await axios.patch(
        `http://localhost:8080/api/seller/orders/${selectedOrderId}/status/${selectedStatus}`,
        {},
        {
          headers: {
            "Authorization": `Bearer ${token}`,
          },
        }
      );

      console.log("Response from backend:", response);

      // If the request was successful, update the orders state to reflect the updated status
      if (response.status === 202) {
        setOrders((prevOrders) =>
          prevOrders.map((order) =>
            order.id === selectedOrderId
              ? { ...order, orderStatus: selectedStatus }
              : order
          )
        );

        // Close the dialog
        setOpenDialog(false);

        // Reload the page after dialog closes
        setTimeout(() => {
          window.location.reload(); // Reload the page after status update
        }, 200);
      }
    } catch (error) {
      console.error("Error updating order status", error);
    }
  };

  // Handle page change
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  // Handle rows per page change
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0); // Reset to first page when rows per page is changed
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  // Slice the orders for pagination
  const paginatedOrders = orders.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  return (
    <>
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 700 }} aria-label="customized table">
          <TableHead>
            <TableRow>
              <StyledTableCell>Order Id</StyledTableCell>
              <StyledTableCell>Products</StyledTableCell>
              <StyledTableCell align="right">Shipping Address</StyledTableCell>
              <StyledTableCell align="right">Status</StyledTableCell>
              <StyledTableCell align="right">Update</StyledTableCell>
            </TableRow>
          </TableHead>
          {/* <TableBody>
            {paginatedOrders.map((order) => (
              <StyledTableRow key={order.id}>
                <StyledTableCell component="th" scope="row">
                  {order.orderId}
                </StyledTableCell>
                <StyledTableCell>
                  {order.orderItems
                    .map((item) => item.product?.title)
                    .join(", ") || "No Products"}
                </StyledTableCell>
                <StyledTableCell align="right">
                  {order.shippingAddress
                    ? `${order.shippingAddress.address}, ${order.shippingAddress.city}`
                    : "N/A"}
                </StyledTableCell>
                <StyledTableCell align="right">
                  <span
                    style={{
                      backgroundColor: statusColors[order.orderStatus],
                      color: "white",
                      padding: "5px 10px",
                      borderRadius: "15px",
                    }}
                  >
                    {statusLabels[order.orderStatus]}
                  </span>
                </StyledTableCell>
                <StyledTableCell align="right">
                  <Button
                    onClick={() => handleChangeStatus(order.id, order.orderStatus)}
                    variant="outlined"
                    color="primary"
                  >
                    Change
                  </Button>
                </StyledTableCell>
              </StyledTableRow>
            ))}
          </TableBody> */}

          <TableBody>
            {orders.length === 0 ? (
              <StyledTableRow>
                <StyledTableCell colSpan={5} align="center">
                  No orders available.
                </StyledTableCell>
              </StyledTableRow>
            ) : (
              paginatedOrders.map((order) => (
                <StyledTableRow key={order.id}>
                  <StyledTableCell component="th" scope="row">
                    {order.orderId}
                  </StyledTableCell>
                  <StyledTableCell>
                    {order.orderItems
                      .map((item) => item.product?.title)
                      .join(", ") || "No Products"}
                  </StyledTableCell>
                  <StyledTableCell align="right">
                    {order.shippingAddress
                      ? `${order.shippingAddress.address}, ${order.shippingAddress.city}`
                      : "N/A"}
                  </StyledTableCell>
                  <StyledTableCell align="right">
                    <span
                      style={{
                        backgroundColor: statusColors[order.orderStatus],
                        color: "white",
                        padding: "5px 10px",
                        borderRadius: "15px",
                      }}
                    >
                      {statusLabels[order.orderStatus]}
                    </span>
                  </StyledTableCell>
                  <StyledTableCell align="right">
                    <Button
                      onClick={() => handleChangeStatus(order.id, order.orderStatus)}
                      variant="outlined"
                      color="primary"
                    >
                      Change
                    </Button>
                  </StyledTableCell>
                </StyledTableRow>
              ))
            )}
          </TableBody>

        </Table>
      </TableContainer>

      {/* Pagination Component */}
      <TablePagination
        rowsPerPageOptions={[5, 10, 25]}
        component="div"
        count={orders.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />

      {/* Modal for status update */}
      <Dialog open={openDialog} onClose={() => setOpenDialog(false)}>
        <DialogTitle>Update Order Status</DialogTitle>
        <DialogContent>
          <FormControl fullWidth>
            <InputLabel >Status</InputLabel>
            <Select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
            >
              <MenuItem value="PENDING">Pending</MenuItem>
              <MenuItem value="PLACED">Placed</MenuItem>
              <MenuItem value="CONFIRMED">Confirmed</MenuItem>
              <MenuItem value="SHIPPED">Shipped</MenuItem>
              <MenuItem value="DELIVERED">Delivered</MenuItem>
              <MenuItem value="CANCELLED">Cancelled</MenuItem>
            </Select>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)} color="primary">
            Cancel
          </Button>
          <Button onClick={handleUpdateStatus} color="primary">
            Update
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default OrderTable;
