import React, { useState, useCallback } from 'react';
import { Box, Button, Grid, TextField, Snackbar, CircularProgress, Alert, Typography } from '@mui/material';

const AddressForm = ({ onClose }) => {
  const [formData, setFormData] = useState({
    name: '',
    mobile: '',
    pinCode: '',
    address: '',
    locality: '',
    city: '',
    state: '',
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [openSnackbar, setOpenSnackbar] = useState(false);

  const handleChange = useCallback((e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  }, []);

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name) newErrors.name = 'Name is required';
    if (!formData.mobile || !/^[6-9]\d{9}$/.test(formData.mobile)) newErrors.mobile = 'Invalid mobile number';
    if (!formData.pinCode || !/^[1-9][0-9]{5}$/.test(formData.pinCode)) newErrors.pinCode = 'Invalid pin code';
    if (!formData.address) newErrors.address = 'Address is required';
    if (!formData.locality) newErrors.locality = 'Locality is required';
    if (!formData.city) newErrors.city = 'City is required';
    if (!formData.state) newErrors.state = 'State is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // const handleSubmit = (e) => {
  //   e.preventDefault();

  //   if (validateForm()) {
  //     setIsSubmitting(true);
  //     setSubmitError(null);
  //     setSubmitSuccess(false);

  //     const token = localStorage.getItem('userToken');
  //     if (!token) {
  //       setIsSubmitting(false);
  //       setSubmitError('User is not authenticated');
  //       return;
  //     }

  //     fetch('http://localhost:8080/users/add-address', {
  //       method: 'POST',
  //       headers: {
  //         'Content-Type': 'application/json',
  //         'Authorization': `Bearer ${token}`,
  //       },
  //       body: JSON.stringify(formData),
  //     })
  //       .then((response) => {
  //         if (!response.ok) {
  //           throw new Error('Failed to add address');
  //         }
  //         return response.json();
  //       })
  //       .then((data) => {
  //         setIsSubmitting(false);
  //         setSubmitSuccess(true);
  //         setOpenSnackbar(true);
  //         if (onClose) onClose();
  //       })
  //       .catch((error) => {
  //         setIsSubmitting(false);
  //         setSubmitError('Failed to add address. Please try again.');
  //         setOpenSnackbar(true);
  //       });
  //   }
  // };


  const handleSubmit = (e) => {
    e.preventDefault();
  
    if (validateForm()) {
      setIsSubmitting(true);
      setSubmitError(null);
      setSubmitSuccess(false);
  
      const token = localStorage.getItem('userToken');
      if (!token) {
        setIsSubmitting(false);
        setSubmitError('User is not authenticated');
        return;
      }
  
      fetch('http://localhost:8080/users/add-address', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error('Failed to add address');
          }
          return response.json();
        })
        .then((data) => {
          setIsSubmitting(false);
          setSubmitSuccess(true);
          setOpenSnackbar(true);
  
          if (onClose) onClose();
  
          // Reload the page after successfully adding the address
          window.location.reload();
        })
        .catch((error) => {
          setIsSubmitting(false);
          setSubmitError('Failed to add address. Please try again.');
          setOpenSnackbar(true);
        });
    }
  };
  
  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };

  return (
    <Box sx={{ padding: '20px', maxWidth: 600, margin: '0 auto', backgroundColor: '#f9f9f9', borderRadius: '8px' }}>
      <form onSubmit={handleSubmit}>
        <Grid container spacing={3}>
          {[
            { label: 'Name', name: 'name', xs: 12 },
            { label: 'Mobile', name: 'mobile', xs: 6 },
            { label: 'Pin Code', name: 'pinCode', xs: 6 },
            { label: 'Address', name: 'address', xs: 12 },
            { label: 'Locality', name: 'locality', xs: 12 },
            { label: 'City', name: 'city', xs: 6 },
            { label: 'State', name: 'state', xs: 6 },
          ].map((field) => (
            <Grid item xs={field.xs} key={field.name}>
              <TextField
                fullWidth
                name={field.name}
                label={field.label}
                value={formData[field.name]}
                onChange={handleChange}
                error={!!errors[field.name]}
                helperText={errors[field.name]}
                sx={{
                  '& .MuiInputBase-root': {
                    borderRadius: '8px',
                    backgroundColor: '#fff',
                  },
                }}
              />
            </Grid>
          ))}

<Grid item xs={12}>
              <Box sx={{
                display: 'flex',
                justifyContent: 'center',
              }}>
                <Button
                  type="submit"
                  variant="contained"
                  size="small"
                  sx={{
                    py: '6px', // Reduced padding for a more compact button
                    backgroundColor: '#4B0082', // Green color for the button
                    '&:hover': { backgroundColor: '#4B0082' }, // Darker green on hover
                    borderRadius: '4px', // Slightly rounded corners
                    textTransform: 'none', // Prevents uppercase transformation of the button text
                  }}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <CircularProgress size={24} sx={{ color: 'white' }} />
                  ) : (
                    'Add Address'
                  )}
                </Button>
              </Box>
            </Grid>

        </Grid>
      </form>

      <Snackbar open={openSnackbar} autoHideDuration={6000} onClose={handleCloseSnackbar}>
        <Alert onClose={handleCloseSnackbar} severity={submitSuccess ? 'success' : 'error'} sx={{ width: '100%' }}>
          {submitSuccess ? 'Address added successfully!' : submitError || 'An unexpected error occurred.'}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default AddressForm;
