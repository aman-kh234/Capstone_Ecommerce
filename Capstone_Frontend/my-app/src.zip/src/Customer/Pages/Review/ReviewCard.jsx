import { Delete, WindowSharp } from '@mui/icons-material';
import { Avatar, Box, Grid, IconButton, Rating } from '@mui/material';
import axios from 'axios';
import React from 'react';
 
const ReviewCard = (prop) => {
  const userToken = localStorage.getItem('userToken');
  const handleDelete = async ()=>{
    // console.log("---------------------------------" + id);
    try {
      const response = await axios.delete(`http://localhost:8080/api/reviews/${prop.review.id}`,
        {
          headers: {
            Authorization: `Bearer ${userToken}`,
          },
        }
      );
      window.location.reload();
    } catch (error) {
      console.error('Error fetching reviews:', error);
    }
  };
  return (
    <div className="flex justify-between">
      <Grid container spacing={8}>
        <Grid item xs={3}>
          <Box>
            <Avatar className="text-white" sx={{ width: 56, height: 56, bgcolor: "#9155FD" }}>
              {prop.review.user.fullName[0]}
            </Avatar>
            <span>{prop.review.user.fullName}</span>
          </Box>
        </Grid>
        <Grid item xs={9}>
          <div className="space-y-2">
            <div>
              <p className="font-semibold text-lg">{prop.review.reviewText}</p>
              <p className="opacity-70">2024-12-03</p>
            </div>
          </div>
          <Rating readOnly value={prop.review.rating} precision={0.5} />
          <p>{prop.review.rating}</p>
          <div>
          </div>
        </Grid>
      </Grid>
      <div>
        {prop.userEmail === prop.review.user.email ?  
        <IconButton color="error" onClick={()=>{handleDelete()}}>
          <Delete />
        </IconButton>
        : "not your review"
        }
      </div>
    </div>
  );
};
 
export default ReviewCard;