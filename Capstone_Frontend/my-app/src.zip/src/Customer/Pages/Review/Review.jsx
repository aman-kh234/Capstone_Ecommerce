import React, { useEffect, useState } from 'react';
import ReviewCard from './ReviewCard';
import { Divider, Button, Dialog, DialogActions, DialogContent, DialogTitle, TextField, Rating } from '@mui/material';
import axios from 'axios';

const Review = (prop) => {
  const [review, setReview] = useState([]);
  const [open, setOpen] = useState(false); // For dialog visibility
  const [newReview, setNewReview] = useState({ text: '', rating: 0 }); // For new review inputs
  const userToken = localStorage.getItem('userToken'); // Assuming token is stored in localStorage

  // Fetch reviews from API
  const fetchReview = async (id) => {
    console.log("---------------------------------" + id);
    try {
      const response = await axios.get(`http://localhost:8080/api/products/${id}/reviews`);
      setReview(response.data);
    } catch (error) {
      console.error('Error fetching reviews:', error);
    }
  };

  // Handle dialog open/close
  const handleClickOpen = () => setOpen(true);
  const handleClose = () => {
    setOpen(false);
    setNewReview({ text: '', rating: 0 });
  };

  // Handle review submission
  const handleSubmit = async () => {
    try {
      console.log(newReview.text + " " + newReview.rating)
     
      console.log(newReview, "--------", newReview.text)
      const reponse = await axios.post(
        `http://localhost:8080/api/products/${prop.products}/reviews`,
        {
          reviewText: newReview.text,
          reviewRating: newReview.rating,
        },
        {
          headers: {
            Authorization: `Bearer ${userToken}`,
          },
        }
      );
      fetchReview(prop.products); // Refresh reviews
      handleClose();
    } catch (error) {
      console.error('Error adding review:', error);
    }
  };

  useEffect(() => {
    fetchReview(prop.products);
  }, []);

  return (
    <div>
     
      <div className="flex items-center justify-between mb-4 mt-6">
        <h1 className="font-bold text-[30px]">Reviews</h1>
        <Button variant="contained" color="primary" onClick={handleClickOpen}>
          Add Review
        </Button>
      </div>


      <div className="p-5 lg:px-20 flex flex-col lg:flex-row gap-20 border border-gray-300">
        <section className="w-full lg:w-[120%]">
          <div
            className="space-y-5 w-full"
            style={{
              maxHeight: '300px',
              overflowY: 'auto',
              scrollbarWidth: 'none',
              msOverflowStyle: 'none',
            }}
          >
            {review.length > 0 ? (
              review.map((item, index) => (
                <div key={index} className="space-y-5">
                  <ReviewCard review={item} userEmail={prop.userEmail} />
                  <Divider />
                </div>
              ))
            ) : (
              "No reviews currently present"
            )}
          </div>
        </section>
      </div>

      {/* Dialog for adding a new review */}
      <Dialog open={open} onClose={handleClose} fullWidth maxWidth="sm">
        <DialogTitle>Add a Review</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Review Text"
            type="text"
            fullWidth
            multiline
            rows={4}
            value={newReview.text}
            onChange={(e) => setNewReview({ ...newReview, text: e.target.value })}
          />
          <div className="flex items-center mt-4">
            <span className="mr-4">Rating:</span>
            <Rating
              value={newReview.rating}
              onChange={(e) => setNewReview({ ...newReview, rating: Number(e.target.value) })}
            />
          </div>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="secondary">
            Cancel
          </Button>
          <Button onClick={handleSubmit} variant="contained" color="primary">
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default Review;