import React from 'react';
import DrawerList from '../../component/DrawerList';
import {
  AccountBox,
  Add,
  Category,
  Dashboard,
  ElectricBolt,
  Home,
  IntegrationInstructions,
  LocalOffer,
  Logout
} from '@mui/icons-material';
 
const menu = [
  {
    name: "Seller",
    path: "/admin",
    icon: <Dashboard sx={{ color: "primary.main"}}/>,
    activeIcon: <Dashboard className="text-white" />
  },
  {
    name: "Customer",
    path: "/admin/customer",
    icon: <Dashboard sx={{ color: "primary.main"}}/>,
    activeIcon: <Dashboard className="text-white" />
  },
  {
    name: "Coupons",
    path: "/admin/coupon",
    icon: <IntegrationInstructions sx={{ color: "primary.main"}}/>,
    activeIcon: <IntegrationInstructions className="text-white" />
  },
  {
    name: "Add New Coupon",
    path: "/admin/add-coupon",
    icon: <Add sx={{ color: "primary.main"}} />,
    activeIcon: <Add className="text-white" />
  },
  
  // {
  //   name: "Electronics Category",
  //   path: "/admin/electronics-category",
  //   icon: <ElectricBolt sx={{ color: "primary.main"}} />,
  //   activeIcon: <ElectricBolt className="text-white" />
  // },
  // {
  //   name: "Shop By Category",
  //   path: "/admin/shop-by-category",
  //   icon: <Category sx={{ color: "primary.main"}} />,
  //   activeIcon: <Category className="text-white" />
  // },
  // {
  //   name: "Deals",
  //   path: "/admin/deals",
  //   icon: <LocalOffer sx={{ color: "primary.main"}} />,
  //   activeIcon: <LocalOffer className="text-white" />
  // }
];
 
const menu2 = [
  {
    name: "Account",
    path: "/admin/account",
    icon: <AccountBox sx={{ color: "primary.main"}} />,
    activeIcon: <AccountBox className="text-white" />
  },
  {
    name: "Logout",
    path: "/",
    icon: <Logout sx={{ color: "primary.main"}} />,
    activeIcon: <Logout className="text-white" />
  }
];
 
const AdminDrawerList = ({ toggleDrawer }) => {
  return <DrawerList menu={menu} menu2={menu2} toggleDrawer={toggleDrawer} />;
};
 
export default AdminDrawerList;