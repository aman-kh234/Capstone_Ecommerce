import React, { useState, useEffect } from "react";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Paper,
  Table,
  TableBody,
  TableCell,
  tableCellClasses,
  TableContainer,
  TableHead,
  TableRow,
  styled,
  Card,
  CardContent,
  Typography,
  Grid,
} from "@mui/material";
import axios from "axios";

// Styling for the table cells
const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: theme.palette.action.hover,
  },
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const UsersTable = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [selectedUser, setSelectedUser] = useState(null); // Store selected user for the dialog
  const [openDialog, setOpenDialog] = useState(false); // Controls dialog visibility

  const userToken = localStorage.getItem("userToken");

  // Fetch users data from API
  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true);
      try {
        const response = await axios.get("http://localhost:8080/users/all", {
          headers: {
            Authorization: `Bearer ${userToken}`,
          },
        });
        setUsers(response.data);
      } catch (error) {
        setError("Error fetching users");
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, [userToken]);

  // Handle "View" button click
  const handleViewUserDetails = (user) => {
    setSelectedUser(user);
    setOpenDialog(true); // Open the dialog when "View" is clicked
  };

  // Handle dialog close
  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedUser(null);
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-[#6a1b9a] pb-5 text-center">
        Users Management
      </h1>

      {loading && <p>Loading...</p>}
      {error && <p>{error}</p>}

      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 700 }} aria-label="customized table">
          <TableHead>
            <TableRow>
              <StyledTableCell>Full Name</StyledTableCell>
              <StyledTableCell>Email</StyledTableCell>
              <StyledTableCell align="right">Mobile</StyledTableCell>
              <StyledTableCell align="right">Addresses</StyledTableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {users.length > 0 ? (
              users.map((row) => (
                <StyledTableRow key={row.id}>
                  <StyledTableCell component="th" scope="row">
                    {row.fullName}
                  </StyledTableCell>
                  <StyledTableCell>{row.email}</StyledTableCell>
                  <StyledTableCell align="right">{row.mobile}</StyledTableCell>
                  <StyledTableCell align="right">
                    <Button
                      variant="contained"
                      onClick={() => handleViewUserDetails(row)}
                    >
                      View
                    </Button>
                  </StyledTableCell>
                </StyledTableRow>
              ))
            ) : (
              <StyledTableRow>
                <StyledTableCell colSpan={4} align="center">
                  No users available.
                </StyledTableCell>
              </StyledTableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Dialog for viewing user details */}
      <Dialog open={openDialog} onClose={handleCloseDialog} fullWidth maxWidth="sm">
        <DialogTitle>Details for {selectedUser?.fullName}</DialogTitle>
        <DialogContent>
          <Grid container spacing={2}>
            {/* Email and Mobile Information */}
            {/* <Grid item xs={12}>
              <Typography variant="h6">Email: {selectedUser?.email}</Typography>
              <Typography variant="h6">Mobile: {selectedUser?.mobile}</Typography>
            </Grid> */}

            {/* Addresses Section */}
            <Grid item xs={12}>
              <Typography variant="h6" gutterBottom>
                Addresses:
              </Typography>
              {selectedUser?.addresses?.length > 0 ? (
                selectedUser.addresses.map((address, index) => (
                  <Card key={index} variant="outlined" sx={{ marginBottom: 2 }}>
                    <CardContent>
                      <Typography variant="h6" color="primary">
                        Address {index + 1}
                      </Typography>
                      <Typography variant="body1">
                        <strong>Line 1:</strong> {address.line1}
                      </Typography>
                      <Typography variant="body1">
                        <strong>Line 2:</strong> {address.line2}
                      </Typography>
                      <Typography variant="body1">
                        <strong>City:</strong> {address.city}
                      </Typography>
                      <Typography variant="body1">
                        <strong>State:</strong> {address.state}
                      </Typography>
                      <Typography variant="body1">
                        <strong>Zip Code:</strong> {address.zipCode}
                      </Typography>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Typography>No addresses available for this user.</Typography>
              )}
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default UsersTable;
