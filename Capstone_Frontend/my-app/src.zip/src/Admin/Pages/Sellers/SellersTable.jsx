import React, { useState, useEffect } from "react";
import {
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  styled,
  Table,
  TableBody,
  TableCell,
  tableCellClasses,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import axios from "axios";

const accountStatuses = [
  { status: "Pending_Verification", title: "Pending Verification", description: "ACCOUNT IS CREATED BUT NOT YET VERIFIED" },
  { status: "Active", title: "Active", description: "ACCOUNT IS ACTIVE AND IN GOOD STANDING" },
  { status: "Suspended", title: "Suspended", description: "ACCOUNT IS TEMPORARILY SUSPENDED, POSSIBLY DUE TO VIOLATIONS" },
  { status: "Deactivated", title: "Deactivated", description: "ACCOUNT IS DEACTIVATED, USER MAY HAVE CHOSEN TO DEACTIVATE IT" },
  { status: "Banned", title: "Banned", description: "ACCOUNT IS PERMANENTLY BANNED DUE TO SEVERE VIOLATIONS" },
  { status: "Closed", title: "Closed", description: "ACCOUNT IS PERMANENTLY CLOSED, POSSIBLY AT USER REQUEST" },
];

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: theme.palette.action.hover,
  },
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const SellersTable = () => {
  const [accountStatus, setAccountStatus] = useState("Active");
  const [sellers, setSellers] = useState([]);
  const [loading, setLoading] = useState(false); // Loading state
  const [error, setError] = useState(""); // Error state
const [updatedSeller,setUpdatedSeller]=useState({});
const [newSellerStatus,setNewSellerStatus]=useState({});

  const userToken = localStorage.getItem("userToken");

  // Helper function to format status text (removes underscores and capitalizes each word)
  const formatStatus = (status) => {
    return status
      .replace(/_/g, " ") // Replace underscores with spaces
      .replace(/\b\w/g, (char) => char.toUpperCase()); // Capitalize the first letter of each word
  };

  // Fetch sellers data from API
  useEffect(() => {
    const fetchSellers = async () => {
      setLoading(true); // Set loading to true when starting the request
      try {
        const response = await axios.get("http://localhost:8080/seller/all", {
          headers: {
            Authorization: `Bearer ${userToken}`, // Pass the token in the Authorization header
          },
          params: {
            status: accountStatus, // Use 'status' here to match the controller
          },
        });
        setSellers(response.data); // Update the sellers state with the fetched data
      } catch (error) {
        setError("Error fetching sellers"); // Set error message in case of failure
      } finally {
        setLoading(false); // Set loading to false once the request is complete
      }
    };



    fetchSellers();
  }, [userToken, accountStatus]); // Re-run if userToken or accountStatus changes

  const handleChange = (event) => {
    setAccountStatus(event.target.value);
  };
  const updateSellerStatus=async(updatedSeller)=>{
console.log("Updated seller",updatedSeller);
    const response=await axios.patch("http://localhost:8080/seller/updateSellerStatus" ,updatedSeller, {
      headers: {
        Authorization: `Bearer ${userToken}`, // Pass the token in the Authorization header
      },
    })
    console.log("updationn response->>>>",response)
  }
  
  return (
    <div>
      <h1 className="text-2xl font-bold text-[#6a1b9a] pb-5 text-center">Sellers Management</h1>

      <div className="pb-5 w-60">
        <FormControl fullWidth>
          <InputLabel id="demo-simple-select-label">Account Status</InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={accountStatus}
            label="Account Status"
            onChange={handleChange}
          >
            {accountStatuses.map((item) => (
              <MenuItem key={item.status} value={item.status}>
                {item.title}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </div>

      {loading && <p>Loading...</p>}
      {error && <p>{error}</p>}

      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 700 }} aria-label="customized table">
          <TableHead>
            <TableRow>
              <StyledTableCell>Seller Name</StyledTableCell>
              <StyledTableCell>Email</StyledTableCell>
              <StyledTableCell align="right">Mobile</StyledTableCell>
              {/* <StyledTableCell align="right">GSTIN</StyledTableCell> */}
              <StyledTableCell align="right">Business Name</StyledTableCell>
              {/* <StyledTableCell align="right">Business Email</StyledTableCell>
              <StyledTableCell align="right">Business Mobile</StyledTableCell>
              <StyledTableCell align="right">Business Address</StyledTableCell>
              <StyledTableCell align="right">Bank Account Number</StyledTableCell> */}
              <StyledTableCell align="right">Account Status</StyledTableCell>
              <StyledTableCell align="right">Change Status</StyledTableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {sellers.length > 0 ? (
              sellers.map((row) => (
                <StyledTableRow key={row.id}>
                  <StyledTableCell component="th" scope="row">
                    {row.sellerName}
                  </StyledTableCell>
                  <StyledTableCell>{row.email}</StyledTableCell>
                  <StyledTableCell align="right">{row.mobile}</StyledTableCell>
                  {/* <StyledTableCell align="right">{row.gstin || "N/A"}</StyledTableCell> Handle null GSTIN */}
                  <StyledTableCell align="right">{row.businessDetails?.businessName || "N/A"}</StyledTableCell>
                  {/* <StyledTableCell align="right">{row.businessDetails?.businessEmail || "N/A"}</StyledTableCell>
                  <StyledTableCell align="right">{row.businessDetails?.businessMobile || "N/A"}</StyledTableCell>
                  <StyledTableCell align="right">{row.businessDetails?.businessAddress || "N/A"}</StyledTableCell>
                  <StyledTableCell align="right">{row.bankDetails?.accountNumber || "N/A"}</StyledTableCell> */}
                  <StyledTableCell align="right">{formatStatus(row.accountStatus)}</StyledTableCell> {/* Format status */}
                  <StyledTableCell align="right">
                    <div className="d-flex">
                      <div className="pb-5 w-30">
                        <FormControl fullWidth>
                          <InputLabel id="demo-simple-select-label">Account Status</InputLabel>
                          <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            value={newSellerStatus==null?row.accountStatus:newSellerStatus}
                            label="Account Status"
                            onChange={(e)=>{setNewSellerStatus(e.target.value)}}
                          >
                            {accountStatuses.map((item) => (
                              <MenuItem key={item.status} value={item.status}>
                                {item.title}
                              </MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                      </div>
                      <div>

                        <Button variant="contained" onClick={async()=>{row.accountStatus=newSellerStatus;await updateSellerStatus(row);setNewSellerStatus("")}}>Change Status</Button>
                      </div>
                    </div>
                  </StyledTableCell>
                </StyledTableRow>
              ))
            ) : (
              <StyledTableRow>
                <StyledTableCell colSpan={11} align="center">
                  No sellers available for this status.
                </StyledTableCell>
              </StyledTableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};

export default SellersTable;
