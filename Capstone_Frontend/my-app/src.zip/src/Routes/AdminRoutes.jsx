import React from 'react'
import { Route, Routes } from 'react-router-dom'
import SellersTable from '../Admin/Pages/Sellers/SellersTable'
import Coupon from '../Admin/Pages/Coupon/Coupon'
import AddNewCouponForm from '../Admin/Pages/Coupon/AddNewCouponForm'
import UsersTable from '../Admin/Pages/Users/UsersTable'
import Account from '../Admin/Pages/Account/Account'
// import GridTable from '../admin/Pages/HomePage/GridTable'
// import ElectronicTable from '../admin/Pages/HomePage/ElectronicTable'
// import ShopByCategoryTable from '../admin/Pages/HomePage/ShopByCategoryTable'
// import Deal from '../admin/Pages/HomePage/'
 
const AdminRoutes = () => {
  return (
    <div>
        <Routes>
            <Route path='/' element={<SellersTable />} />
            <Route path='/coupon' element={<Coupon />} />
            <Route path='/add-coupon' element={<AddNewCouponForm />} />
            <Route path='/customer' element={<UsersTable />} />
            {/* <Route path='/electronics-category' element={<ElectronicTable />} /> */}
            {/* <Route path='/shop-by-category' element={<ShopByCategoryTable />} /> */}
            <Route path='/account' element={<Account />} />
          
        </Routes>
    </div>
  )
}
 
export default AdminRoutes