// import { Dashboard } from '@mui/icons-material'
import React, { useEffect } from 'react'
import { Route, Routes, useNavigate } from 'react-router-dom'
import Dashboard from '../Seller/Components/pages/SellerDashBoard/Dashboard'
import Products from '../Seller/Components/pages/Products/Products'
import AddProduct from '../Seller/Components/pages/Products/AddProduct'
import Orders from '../Seller/Components/pages/Orders/Orders'
import Profile from '../Seller/Components/pages/Account/Profile'
import Payment from '../Seller/Components/pages/Payment/Payment'
import Transaction from '../Seller/Components/pages/Transaction/Transaction'
import {jwtDecode} from 'jwt-decode';

const SellerRoutes = () => {
const navigate=useNavigate();

  // const getRoleFromToken = () => {
  //   // Step 1: Get the token from local storage
  //   const sellerToken = localStorage.getItem('sellerToken'); // or sessionStorage
  // console.log("inside get toknfrom local storage");
  // console.log("Token->",sellerToken)
  //   if (sellerToken) {
  //     try {
  //       // Step 2: Decode the token
  //       const decodedToken = jwtDecode(sellerToken);
  
  //       // Step 3: Check the role in the decoded token (assuming the role is in 'role' claim)
  //       if (decodedToken.role === 'Role_Seller') {
  //         console.log('User is a Seller');
  //         alert("You are a validated seller")
  //         return 'seller';
  //       } else if (decodedToken.role === 'Role_Customer') {
  //         console.log('User is a regular User');
  //         navigate("/");
  //         return 'user';
  //       } else {
  //         console.log('Role is not recognized');
  //         alert("role not recignized");
  //         navigate("/")
  //         return 'unknown';
  //       }
  //     } catch (error) {
  //       console.error('Error decoding token:', error);

  //       return 'error';
  //     }
  //   } else {
  //     console.log('No token found');
  //     navigate("/");
  //     return 'no-token';
  //   }
    
  // };
  
// useEffect(()=>{
// getRoleFromToken();
// },[])

  return (
    <div>
        <Routes>
            <Route path='/'  element={<Dashboard />} />
            <Route path='/products'  element={<Products />} />
            <Route path='/add-product'  element={<AddProduct />} />
            <Route path='/orders'  element={<Orders />} />
            <Route path='/account'  element={<Profile />} />
            <Route path='/payment'  element={<Payment />} />
            <Route path='/transaction'  element={<Transaction />} />
        </Routes>
    </div>
  )
}

export default SellerRoutes